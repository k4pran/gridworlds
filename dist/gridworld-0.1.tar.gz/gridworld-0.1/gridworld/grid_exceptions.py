class GridOutOfBoundsException(Exception):
    pass


class GridGenerateException(Exception):
    pass


class InvalidDimensionsException(Exception):
    pass