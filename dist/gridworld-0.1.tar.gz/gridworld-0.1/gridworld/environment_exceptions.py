class InvalidActionException(Exception):
    pass
